package com.example.shij2.whack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class endgame extends AppCompatActivity {
    private TextView num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_endgame);

        Intent e = getIntent();
        String endScore =e.getStringExtra(MainActivity.MESSAGE);

        num = findViewById(R.id.num);
        num.setText(endScore);
    }

    public void back(View view) {
        Intent b = new Intent(this, MainActivity.class);
        startActivity(b);
    }

}

package com.example.shij2.whack;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class NS extends AppCompatActivity {

    public Button[] pots = new Button[12];
    private TextView ScoreNum;
    private TextView time;

    public int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ns);

        pots[0] = findViewById(R.id.p7);
        pots[1] = findViewById(R.id.p8);
        pots[2] = findViewById(R.id.p9);
        pots[3] = findViewById(R.id.p10);
        pots[4] = findViewById(R.id.p11);
        pots[5] = findViewById(R.id.p12);
        pots[6] = findViewById(R.id.p13);
        pots[7] = findViewById(R.id.p14);
        pots[8] = findViewById(R.id.p15);
        pots[9] = findViewById(R.id.p16);
        pots[10] = findViewById(R.id.p17);
        pots[11] = findViewById(R.id.p18);

        ScoreNum = findViewById(R.id.ScoreNum);
        time = findViewById(R.id.time);

        new CountDownTimer(60000,1000) {
            public void onTick(long millisLeft) {
                time.setText(millisLeft / 1000 + "");
                if (millisLeft/1000 % 2 == 0) {
                    for (int i = 0; i < pots.length; i++) {
                        pots[i].setBackgroundResource(R.drawable.sap4);
                        pots[i].setEnabled(false);
                    }
                    Random random = new Random();
                    int r = random.nextInt(12);
                    pots[r].setBackgroundResource(R.drawable.kawaii_potato);
                    pots[r].setEnabled(true);
                }
            }
            @Override
            public void onFinish() {
                end();
            }
        }.start();
    }

    public void back(View view) {
        Intent b = new Intent(this, MainActivity.class);
        startActivity(b);
    }

    public void end() {
        Intent e = new Intent(this, endgame.class);
        String message = ScoreNum.getText().toString();
        e.putExtra(MainActivity.MESSAGE, message);
        startActivity(e);
    }

    public void end(View view) {
        Intent e = new Intent(this, endgame.class);
        String message = this.ScoreNum.getText().toString();
        e.putExtra(MainActivity.MESSAGE, message);
        startActivity(e);
    }

    public void click(View view) {
        for (int i = 0; i < pots.length; i++) {
            pots[i].setBackgroundResource(R.drawable.sap4);
            pots[i].setEnabled(false);
        }
        score++;
        ScoreNum.setText("" + score);
    }
}

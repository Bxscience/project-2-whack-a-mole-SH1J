package com.example.shij2.whack;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class HS extends AppCompatActivity {

    public Button[] pots = new Button[20];
    private TextView ScoreNum;
    private TextView time;

    public int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hs);

        pots[0] = findViewById(R.id.p20);
        pots[1] = findViewById(R.id.p21);
        pots[2] = findViewById(R.id.p22);
        pots[3] = findViewById(R.id.p23);
        pots[4] = findViewById(R.id.p24);
        pots[5] = findViewById(R.id.p25);
        pots[6] = findViewById(R.id.p26);
        pots[7] = findViewById(R.id.p27);
        pots[8] = findViewById(R.id.p28);
        pots[9] = findViewById(R.id.p29);
        pots[10] = findViewById(R.id.p30);
        pots[11] = findViewById(R.id.p31);
        pots[12] = findViewById(R.id.p32);
        pots[13] = findViewById(R.id.p33);
        pots[14] = findViewById(R.id.p34);
        pots[15] = findViewById(R.id.p35);
        pots[16] = findViewById(R.id.p36);
        pots[17] = findViewById(R.id.p37);
        pots[18] = findViewById(R.id.p38);
        pots[19] = findViewById(R.id.p39);

        ScoreNum = findViewById(R.id.ScoreNum);
        time =  findViewById(R.id.time);

        new CountDownTimer(60000,250) {
            public void onTick(long millisLeft) {
                time.setText(millisLeft / 1000 + "");
                if (millisLeft/1000 % 2 == 0) {
                    for (int i = 0; i < pots.length; i++) {
                        pots[i].setBackgroundResource(R.drawable.sap4);
                        pots[i].setEnabled(false);
                    }
                    Random random = new Random();
                    int r = random.nextInt(20);
                    pots[r].setBackgroundResource(R.drawable.kawaii_potato);
                    pots[r].setEnabled(true);
                }
            }
            @Override
            public void onFinish() {
                end();
            }
        }.start();
    }

    public void back(View view) {
        Intent b = new Intent(this, MainActivity.class);
        startActivity(b);
    }

    public void end() {
        Intent e = new Intent(this, endgame.class);
        String message = this.ScoreNum.getText().toString();
        e.putExtra(MainActivity.MESSAGE, message);
        startActivity(e);

    }

    public void end(View view) {
        Intent e = new Intent(this, endgame.class);
        String message = this.ScoreNum.getText().toString();
        e.putExtra(MainActivity.MESSAGE, message);
        startActivity(e);
    }

    public void click(View view) {
        for (int i = 0; i < pots.length; i++) {
            pots[i].setBackgroundResource(R.drawable.sap4);
            pots[i].setEnabled(false);
        }
        score++;
        ScoreNum.setText("" +score);
    }
}

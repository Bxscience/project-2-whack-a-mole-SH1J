package com.example.shij2.whack;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class VES extends AppCompatActivity {
    private TextView ScoreNum;
    private Button noGod;

    public int score =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ves);

        ScoreNum = (TextView) findViewById(R.id.ScoreNum);
        noGod = (Button) findViewById(R.id.noG);

        final MediaPlayer no = MediaPlayer.create(this, R.raw.nog);

        noGod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                no.start();
                score++;
                ScoreNum.setText(Integer.toString(score));
            }
        });
    }

    public void back(View view) {
        Intent b = new Intent(this, MainActivity.class);
        startActivity(b);
    }

    public void end(View view) {
        Intent e = new Intent(this, endgame.class);
        String message = this.ScoreNum.getText().toString();
        e.putExtra(MainActivity.MESSAGE, message);
        startActivity(e);
    }
}

package com.example.shij2.whack;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public static final String MESSAGE = "HI!";
    private Button click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        click = (Button) findViewById(R.id.click);
    }

    //1x1
    public void VeryEasy(View view) {
        Intent ve = new Intent(this, VES.class);
        startActivity(ve);
    }

    //2x3
    public void Easy(View view) {
        Intent e = new Intent(this, ES.class);
        startActivity(e);
    }

    //3x4
    public void Normal(View view) {
        Intent n = new Intent(this, NS.class);
        startActivity(n);
    }

    //4x5
    public void Hard(View view) {
        Intent h = new Intent(this, HS.class);
        startActivity(h);
    }

    int a = 0;
    public void useless(View view) {
        a += 1;

        if ((a % 3) == 1) {
            click.setBackground(this.getResources().getDrawable(R.drawable.kawaii_potato));
        } else if ((a % 3) == 2) {
            click.setBackground(this.getResources().getDrawable(R.drawable.hit));
        } else {
            click.setBackground(this.getResources().getDrawable(R.drawable.sap4));
        }
    }
}
